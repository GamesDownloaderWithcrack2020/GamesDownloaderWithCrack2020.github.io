﻿Public Class Form1
    Private Sub ProgressBar1_Click(sender As Object, e As EventArgs) Handles ProgressBar1.Click
        ColorDialog1.ShowDialog()
        ProgressBar1.ForeColor = ColorDialog1.Color
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        'Threading.Thread.Sleep(5000)
        If fgchk.Checked = True Then
            If euelka.Checked = True Then
                download.Start()
            Else
                MsgBox("Zaznacz eule!")
            End If

        Else
            MsgBox("Error")
        End If
    End Sub

    Private Sub build_Tick(sender As Object, e As EventArgs) Handles build.Tick
        buildbar.Increment(1)
        Label2.Text = "Building a Virus for You"
        If buildbar.Value = 100 Then
            build.Stop()
            Label2.Text = "Done. Virus build succesful and installed"
            MsgBox("Done. Enjoy using!!! :D")
            Threading.Thread.Sleep(3500)
            MsgBox("It's a prank!! :D (xD)")
        End If
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        build.Start()
    End Sub

    Private Sub download_Tick(sender As Object, e As EventArgs) Handles download.Tick
        ProgressBar1.Increment(1)
        Label3.Text = "Downloading and Installing Fall Guys " + ProgressBar1.Value.ToString + " %"
    End Sub

    Private Sub CheckBox1_CheckedChanged(sender As Object, e As EventArgs) Handles euelka.CheckedChanged
        euelka.Checked = True
        eula.Show()
        Me.Hide()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        If ProgressBar1.Value = 100 Then
            MsgBox("Cracked Fall Guys: Ultimate Knockout (edited files amtinst.dll.lib)")
        Else
            MsgBox("Error: Fall Guys are not installed")
        End If
    End Sub

    Private Sub CheckBox10_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox10.CheckedChanged
        MsgBox("NIE MA DAŁNIE XD 30 LAT DDOSA :D")
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        MsgBox("Cancel: Nie ma canel cebulko za to masz 20 lat ddosa")
    End Sub

    Private Sub PictureBox1_Click(sender As Object, e As EventArgs) Handles PictureBox1.Click
        Dim webAddress As String = "http://google.co.ck/search?q=my+computer+is+doing+weird+things+wtf+is+happenin+plz+halp"
        Process.Start(webAddress)
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        MsgBox("Nie")
    End Sub

    Private Sub Label4_Click(sender As Object, e As EventArgs)
        MsgBox("Data końca : 20.09.2020r. wyjście na github 27.09.2020r.")
    End Sub

    Private Sub Button11_Click(sender As Object, e As EventArgs) Handles Button11.Click
        MsgBox("Za późno")
    End Sub

    Private Sub LinkLabel2_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs)
        MsgBox("data końca : 00.00.00r. już weszło !")
    End Sub

    Private Sub Label5_Click(sender As Object, e As EventArgs)
        MsgBox("data końca : 30.09.20r. wyjście : 03.10.20r. ")
    End Sub

    Private Sub Label6_Click(sender As Object, e As EventArgs)
        MsgBox("data końca : 05.10.20r. wyjście : 07.10.20r.")
    End Sub

    Private Sub Label7_Click(sender As Object, e As EventArgs)
        MsgBox("data końca 10.10.20r. wyjście 13.10.20r.")
    End Sub

    Private Sub Label8_Click(sender As Object, e As EventArgs)
        MsgBox("data końca : 2021r. data wyjścia 2021r.")
    End Sub

    Private Sub LinkLabel3_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs)

    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub PictureBox3_Click(sender As Object, e As EventArgs) Handles PictureBox3.Click
        MsgBox("Akcepted")
    End Sub

    Private Sub LinkLabel3_LinkClicked_1(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel3.LinkClicked
        MsgBox("Nie skończone")
    End Sub

    Private Sub TabPage1_Click(sender As Object, e As EventArgs) Handles TabPage1.Click
        MsgBox("Nie skończone")
    End Sub

    Private Sub LinkLabel5_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel5.LinkClicked
        MsgBox("Nie skończone")
    End Sub

    Private Sub LinkLabel6_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel6.LinkClicked
        MsgBox("Skończone")
    End Sub

    Private Sub ProgressBar4_Click(sender As Object, e As EventArgs)
        ColorDialog1.ShowDialog()
        ProgressBar1.ForeColor = ColorDialog1.Color
    End Sub

    Private Sub LinkLabel4_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel4.LinkClicked
        MsgBox("Nie skończone")
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick

    End Sub

    Private Sub Button5_Click_1(sender As Object, e As EventArgs) 

    End Sub

    Private Sub Button6_Click(sender As Object, e As EventArgs) 

    End Sub

    Private Sub ProgressBar5_Click(sender As Object, e As EventArgs) 

    End Sub
End Class
