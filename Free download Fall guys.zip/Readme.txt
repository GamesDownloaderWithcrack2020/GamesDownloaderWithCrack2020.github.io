1. Extract my files
2. open -Gamesdownloadercrack2020-bin-debug-.exe
Thanks for downloading
3. open .exe
3. Install fall guys
4. Game is ready
5. close window please
Thanks for downloading.
You is good guy.

13:14 20.09.2020

Me : https://www.youtube.com/watch?v=cdZiQuzbeW4
Frend : https://www.youtube.com/watch?v=MQIz7TlC8VQ&t=3s