﻿Public Class eula
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Me.Hide()
        MsgBox("fuck you zaakceptowales. Dziekujemy za uwage")
        Form1.Show()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Me.Hide()
        MsgBox("Dziekujemy za uwage. Masz 7 dni na przeprowadzke. Czas plynie na minus - 3 dni na czytanie")
        Form1.Show()
    End Sub
End Class